import 'package:flutter/material.dart' show runApp;
import 'presentation/my_app.dart';

void main() {
  runApp(const MyApp());
}

